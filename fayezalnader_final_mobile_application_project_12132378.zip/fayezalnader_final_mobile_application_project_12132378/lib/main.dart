import 'package:flutter/material.dart';
import 'screens/landing_page.dart'; // Correct import

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fayez Al Nader App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LandingPage(), // This should be defined in landing_page.dart
    );
  }
}
