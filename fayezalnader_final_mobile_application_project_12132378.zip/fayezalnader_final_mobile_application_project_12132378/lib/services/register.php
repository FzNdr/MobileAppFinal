<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
require 'db_connection.php';
require 'client_functions.php';
require 'driver_functions.php';
require 'authentication.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'register') {
        $userType = htmlspecialchars(trim($_POST['user_type'])); // Either 'client' or 'driver'

        try {
            // Determine if user type is valid
            if (!in_array($userType, ['client', 'driver'])) {
                throw new Exception("Invalid user type selected.");
            }

            // Common data fields for client and driver
            $commonData = [
                'username' => htmlspecialchars(trim($_POST['username'])),
                'password' => htmlspecialchars(trim($_POST['password'])),
                'first_name' => htmlspecialchars(trim($_POST['first_name'])),
                'last_name' => htmlspecialchars(trim($_POST['last_name'])),
                'phone_number' => htmlspecialchars(trim($_POST['phone_number'])),
                'id_number' => htmlspecialchars(trim($_POST['id_number'])),
                'passport_number' => htmlspecialchars(trim($_POST['passport_number']))
            ];

            // check common fields
            foreach ($commonData as $key => $value) {
                if (empty($value)) {
                    throw new Exception("The field '$key' is required.");
                }
            }

            // Check if username already exist
            $usernameExistsQuery = "SELECT 1 FROM " . ($userType === 'client' ? 'clients' : 'drivers') . " WHERE username = ?";
            $stmt = $conn->prepare($usernameExistsQuery);
            $stmt->bind_param("s", $commonData['username']);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                throw new Exception("The username is already taken. Please choose a different username.");
            }
            $stmt->close();

           
            if ($userType === 'client') {
                // Register client
                registerClient($commonData, $conn);

                // Redirect to client map
                header('Location: ../ClientMap.html');
                exit();
            } elseif ($userType === 'driver') {
                // fields for drivers
                $driverData = [
                    'vehicle_brand' => htmlspecialchars(trim($_POST['vehicle_brand'])),
                    'vehicle_type' => htmlspecialchars(trim($_POST['vehicle_type'])),
                    'available_seats' => (int)$_POST['vehicle_seats']
                ];

                // check driver fields
                foreach ($driverData as $key => $value) {
                    if (empty($value) && $key !== 'available_seats') { // available_seats can be 0
                        throw new Exception("The field '$key' is required.");
                    }
                }

                // merge common fiels with driver data
                $driverData = array_merge($commonData, $driverData);

                // Register driver
                registerDriver($driverData, $conn);

                // Redirect to driver map
                header('Location: ../DriverMap.html');
                exit();
            }
        } catch (Exception $e) {
            // Log  error for debug
            error_log($e->getMessage());

            // Display error message to use
            echo "<p style='color: red;'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }
}

$conn->close();
?>