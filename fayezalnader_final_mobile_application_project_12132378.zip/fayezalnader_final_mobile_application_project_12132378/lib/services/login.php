<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
require_once 'db_connection.php';
require_once 'client_functions.php';
require_once 'driver_functions.php';
require_once 'authentication.php';

// Start session to track user
session_start();

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $isDriver = $_POST['user_type'] === 'driver';

    // Auth user
    if (authenticateUser($username, $password, $isDriver, $conn)) {
        // Store user information in session
        $_SESSION['username'] = $username;
        $_SESSION['user_type'] = $isDriver ? 'driver' : 'client';
        
        // Redirect to map page based on user type
        if ($isDriver) {
            header("Location: ../DriverMap.html");
        } else {
            header("Location: ../ClientMap.html");
        }
        exit();
    } else {
        echo "Invalid credentials. Please try again.";
    }
}
?>