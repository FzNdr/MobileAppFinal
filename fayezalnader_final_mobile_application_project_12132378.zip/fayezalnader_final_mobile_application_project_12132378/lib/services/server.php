<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
require 'db_connection.php';
require 'client_functions.php';
require 'driver_functions.php';
require 'authentication.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'registerClient') {
        // get client info
        $clientData = [
            'username' => $_POST['username'],
            'password' => $_POST['password'],
            'first_name' => $_POST['first_name'],
            'last_name' => $_POST['last_name'],
            'phone_number' => $_POST['phone_number'],
            'id_number' => $_POST['id_number'],
            'passport_number' => $_POST['passport_number'],
            'client_alt' => $_POST['client_alt'],
            'client_lat' => $_POST['client_lat']
        ];
        registerClient($clientData, $conn);
        echo "Client registered successfully.";
    } elseif ($action === 'registerDriver') {
        //get driver info
        $driverData = [
            'username' => $_POST['username'],
            'password' => $_POST['password'],
            'first_name' => $_POST['first_name'],
            'last_name' => $_POST['last_name'],
            'phone_number' => $_POST['phone_number'],
            'id_number' => $_POST['id_number'],
            'passport_number' => $_POST['passport_number'],
            'vehicle_brand' => $_POST['vehicle_brand'],
            'vehicle_type' => $_POST['vehicle_type'],
            'available_seats' => $_POST['available_seats'],
            'driver_lat' => $_POST['driver_lat'],
            'driver_alt' => $_POST['driver_alt']
        ];
        registerDriver($driverData, $conn);
        echo "Driver registered successfully.";
    } elseif ($action === 'login') {
        // check if user is driver or client
        $isDriver = $_POST['user_type'] === 'driver';
        $username = $_POST['username'];
        $password = $_POST['password'];

        if (authenticateUser($username, $password, $isDriver, $conn)) {
            echo "Login successful.";
        } else {
            echo "Invalid credentials.";
        }
    }
}

$conn->close();
?>