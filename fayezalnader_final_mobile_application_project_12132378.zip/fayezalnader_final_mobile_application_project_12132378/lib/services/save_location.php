<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
session_start();
require 'database_connection.php';

// Check if the client is logged in
if (!isset($_SESSION['client_id'])) {
    http_response_code(401); // Unauthorized
    echo json_encode(['error' => 'User not logged in']);
    exit;
}

// Fetch client ID from  session
$clientId = $_SESSION['client_id'];

// Get location data from client
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['client_lat']) || !isset($data['client_lng'])) {
    http_response_code(400); // Bad request
    echo json_encode(['error' => 'Invalid location data']);
    exit;
}

// Sanitize  input
$clientLat = filter_var($data['client_lat'], FILTER_VALIDATE_FLOAT);
$clientLng = filter_var($data['client_lng'], FILTER_VALIDATE_FLOAT);

if ($clientLat === false || $clientLng === false) {
    http_response_code(400); // Bad request
    echo json_encode(['error' => 'Invalid latitude or longitude']);
    exit;
}

// Update client location in DB
$query = "UPDATE clients SET client_lat = ?, client_alt = ? WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ddi", $clientLat, $clientLng, $clientId);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Location updated']);
} else {
    http_response_code(500); // Internal server error
    echo json_encode(['error' => 'Failed to update location']);
}

// Check if req method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Decode JSON payload
    $data = json_decode(file_get_contents('php://input'), true);

    // Retrieve data from req
    $userType = $data['userType']; // if driver or client
    $userId = $data['userId'];
    $latitude = $data['latitude'];
    $longitude = $data['longitude'];

    // check input
    if (empty($userType) || empty($userId) || !is_numeric($latitude) || !is_numeric($longitude)) {
        http_response_code(400); // Bad Request
        echo json_encode(['status' => 'error', 'message' => 'Invalid input data']);
        exit;
    }

    // select table based on user type
    $table = ($userType === 'driver') ? 'drivers' : 'clients';

    // Prepare SQL query to update  location
    $query = "UPDATE $table SET client_lat = ?, client_alt = ? WHERE id = ?";
    $stmt = $conn->prepare($query);

    // Check if the query was prepared successfully
    if (!$stmt) {
        http_response_code(500); // Internal Server Error
        echo json_encode(['status' => 'error', 'message' => 'Failed to prepare SQL statement']);
        exit;
    }

    // Bind params and execute query
    $stmt->bind_param("ddi", $latitude, $longitude, $userId);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Location updated successfully']);
    } else {
        http_response_code(500); // Internal Server Error
        echo json_encode(['status' => 'error', 'message' => $stmt->error]);
    }

    // Close  statement
    $stmt->close();
} else {
    // If request method is not POST, return  error
    http_response_code(405); // Method Not Allowed
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

$data = json_decode(file_get_contents('php://input'), true);

$clientLat = $data['client_lat'];
$clientLng = $data['client_lng'];

$clientId = $data['id'];

$query = "UPDATE clients SET client_lat = ?, client_lng = ? WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ddi", $clientLat, $clientLng, $clientId);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Location updated"]);
} else {
    echo json_encode(["status" => "error", "message" => $stmt->error]);
}
?>