<?php
// Allow CORS (Cross-Origin Resource Sharing)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

require 'db_connection.php';

function authenticateUser($username, $password, $isDriver, $conn) {
    $table = $isDriver ? 'drivers' : 'clients';
    $usernameColumn = $isDriver ? 'driver_username' : 'username';

    $query = "SELECT password FROM $table WHERE $usernameColumn = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        // Debugging: Log values being compared
        error_log("Password verification attempt for: $username");
        error_log("Submitted Password: $password");
        error_log("Stored Password: " . $row['password']);

        // Compare passwords
        if ($password === $row['password']) {
            return true;
        } else {
            error_log("Password does not match.");
        }
    } else {
        error_log("Username not found.");
    }

    return false;
}
?>
