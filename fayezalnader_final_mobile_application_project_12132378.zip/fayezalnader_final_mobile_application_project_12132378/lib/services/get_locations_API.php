<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
require 'db_connection.php';

$driverId = $_GET['driverId'];
$queryDriver = "SELECT driver_lat, driver_lng FROM drivers WHERE id = ?";
$stmt = $conn->prepare($queryDriver);
$stmt->bind_param("i", $driverId);
$stmt->execute();
$resultDriver = $stmt->get_result();
$driver = $resultDriver->fetch_assoc();

$queryClients = "SELECT id, first_name, client_lat, client_alt, user_phone_number FROM clients";
$resultClients = $conn->query($queryClients);

$clients = [];
while ($row = $resultClients->fetch_assoc()) {
    $clients[] = [
        'id' => $row['id'],
        'name' => $row['first_name'],
        'lat' => $row['client_lat'],
        'lng' => $row['client_lng'],
        'contact' => $row['user_phone_number']
    ];
}

echo json_encode(['driver' => $driver, 'clients' => $clients]);

$userLat = $_GET['lat'];
$userLng = $_GET['lng'];

$queryDrivers = "SELECT id, driver_first_name, driver_last_name, driver_phone_number, vehicle_type, driver_lat, driver_lng FROM drivers";
$result = $conn->query($queryDrivers);

$drivers = [];
while ($row = $result->fetch_assoc()) {
    $drivers[] = $row;
}

echo json_encode(["drivers" => $drivers]);
?>