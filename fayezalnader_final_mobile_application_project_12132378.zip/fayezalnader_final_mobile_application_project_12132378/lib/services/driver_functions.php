<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
require 'db_connection.php';

// register driver
function registerDriver($data, $conn) {
    //  insert new driver in DB
    $stmt = $conn->prepare("INSERT INTO drivers 
    (driver_username, password, driver_first_name, driver_last_name, driver_phone_number, driver_id_number, driver_passport_number, vehicle_brand, vehicle_type, available_seats) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
   
    // Bind params
    $stmt->bind_param(
        "ssssiisssi",
        $data['username'],
        $Password,
        $data['first_name'],
        $data['last_name'],
        $data['phone_number'],
        $data['id_number'],
        $data['passport_number'],
        $data['vehicle_brand'],
        $data['vehicle_type'],
        $data['available_seats'],
        
    );
   
    $stmt->execute();
    $stmt->close();
}
?>