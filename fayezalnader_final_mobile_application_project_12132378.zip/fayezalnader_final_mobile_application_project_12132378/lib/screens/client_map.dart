import 'package:flutter/material.dart';

class ClientMapPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Taxi Service'),
        actions: [
          IconButton(
            icon: const Icon(Icons.nightlight_round),
            onPressed: () {
              // Add toggle light/dark mode functionality here
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Hero Section
            Container(
              width: double.infinity,
              color: Colors.blue[100],
              padding: const EdgeInsets.all(16),
              child: const Text(
                'Track your ride and find the nearest taxis.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
            ),
            // Map Section
            Container(
              height: 500,
              width: double.infinity,
              color: Colors.grey[300],
              child: const Center(
                child: Text('Map Placeholder'),
              ),
            ),
            // Route Control Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'Enter pickup location',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    decoration: const InputDecoration(
                      labelText: 'Enter destination',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      // Add "Find Taxi" functionality here
                    },
                    child: const Text('Find Taxi'),
                  ),
                ],
              ),
            ),
            // Driver Table Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Available Drivers',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Table(
                    border: TableBorder.all(),
                    columnWidths: const {
                      0: FlexColumnWidth(2),
                      1: FlexColumnWidth(2),
                      2: FlexColumnWidth(2),
                      3: FlexColumnWidth(1),
                    },
                    children: const [
                      TableRow(children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'Driver Name',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'Phone Number',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'Vehicle Type',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            'Distance(km)',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ]),
                      TableRow(children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('John Doe'),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('+1234567890'),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('Sedan'),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('N/A'),
                        ),
                      ]),
                      TableRow(children: [
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('Jane Smith'),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('+0987654321'),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('SUV'),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text('N/A'),
                        ),
                      ]),
                    ],
                  ),
                ],
              ),
            ),
            // Footer Section
            Container(
              color: Colors.blue[100],
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              child: const Text(
                'Made By Fayez Al Nader & Tarek Ibrahim for non-profit purposes.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
