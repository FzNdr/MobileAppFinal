import 'package:flutter/material.dart';

class DriverMapPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Driver Map'),
        actions: [
          IconButton(
            onPressed: () {
              // Light/Dark mode toggle logic
            },
            icon: Icon(Icons.brightness_6),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header Section
            Container(
              padding: EdgeInsets.symmetric(vertical: 20),
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Column(
                children: [
                  Image.asset(
                    'assets/TaxiWebsiteLogo.png',
                    height: 100,
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Taxi Service',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            // Hero Section
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.lightBlueAccent,
              child: Text(
                'Track your available rides and navigate to clients.',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
            ),

            // Route Controls Section
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'Enter pickup location',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 10),
                  TextField(
                    decoration: InputDecoration(
                      labelText: 'Enter destination',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () {
                      // Accept ride button logic
                    },
                    child: Text('Accept Ride'),
                  ),
                ],
              ),
            ),

            // Client Table Section
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nearby Clients',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Table(
                    border: TableBorder.all(),
                    columnWidths: const {
                      0: FlexColumnWidth(2),
                      1: FlexColumnWidth(3),
                      2: FlexColumnWidth(2),
                      3: FlexColumnWidth(1),
                    },
                    children: [
                      TableRow(
                        decoration: BoxDecoration(color: Colors.grey[200]),
                        children: [
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'Client Name',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'Pickup Location',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'Destination',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text(
                              'Contact',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                      // Placeholder rows
                      TableRow(
                        children: [
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('Ali Khan'),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('Downtown Plaza'),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('Central Park'),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('+9876543210'),
                          ),
                        ],
                      ),
                      TableRow(
                        children: [
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('Sara Lee'),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('City Mall'),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('Main Street'),
                          ),
                          Padding(
                            padding: EdgeInsets.all(8.0),
                            child: Text('+1234567890'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Footer Section
            Container(
              padding: EdgeInsets.all(20),
              color: Colors.black,
              child: Text(
                'Made By Fayez Al Nader & Tarek Ibrahim for non-profit purposes.',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}