import 'package:flutter/material.dart';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  bool isLogin = true;
  bool isDarkMode = false;

  // Function to toggle between login and register forms
  void toggleLoginRegister() {
    setState(() {
      isLogin = !isLogin;
    });
  }

  // Function to toggle between light and dark mode
  void toggleTheme() {
    setState(() {
      isDarkMode = !isDarkMode;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Landing Page'),
          actions: [
            IconButton(
              icon: Icon(isDarkMode ? Icons.wb_sunny : Icons.nightlight_round),
              onPressed: toggleTheme,
            ),
          ],
        ),
        body: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Page Header
              Text(
                'Welcome to the Landing Page',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              
              // Toggle Login/Register Forms
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: toggleLoginRegister,
                    child: Text('Login'),
                  ),
                  SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: toggleLoginRegister,
                    child: Text('Register'),
                  ),
                ],
              ),
              SizedBox(height: 20),

              // Login or Register Form Displayed Based on isLogin
              if (isLogin)
                Column(
                  children: [
                    TextField(
                      decoration: InputDecoration(labelText: 'Username'),
                    ),
                    TextField(
                      obscureText: true,
                      decoration: InputDecoration(labelText: 'Password'),
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {},
                      child: Text('Login'),
                    ),
                  ],
                )
              else
                Column(
                  children: [
                    TextField(
                      decoration: InputDecoration(labelText: 'Full Name'),
                    ),
                    TextField(
                      decoration: InputDecoration(labelText: 'Email'),
                    ),
                    TextField(
                      obscureText: true,
                      decoration: InputDecoration(labelText: 'Password'),
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {},
                      child: Text('Register'),
                    ),
                  ],
                ),

              // Theme Toggle Button
              Padding(
                padding: const EdgeInsets.only(top: 20),
                child: ElevatedButton(
                  onPressed: toggleTheme,
                  child: Text(isDarkMode ? '🌙' : '🌞'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
