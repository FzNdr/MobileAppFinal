package com.example.fayezalnader_final_mobile_application_project_12132378

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
